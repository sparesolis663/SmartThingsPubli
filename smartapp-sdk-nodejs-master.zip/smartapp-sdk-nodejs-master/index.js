'use strict'
const SmartApp = require('./lib/smart-app')

module.exports = SmartApp
module.exports.SmartApp = SmartApp
