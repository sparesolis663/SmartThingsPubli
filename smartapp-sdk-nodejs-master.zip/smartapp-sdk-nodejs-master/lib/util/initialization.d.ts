export class Initialization {
    firstPageId(value: string)
    permissions(value: string | string[])
    disableCustomDisplayName(value?: boolean)
    disableRemoveApp(value?: boolean)
}
