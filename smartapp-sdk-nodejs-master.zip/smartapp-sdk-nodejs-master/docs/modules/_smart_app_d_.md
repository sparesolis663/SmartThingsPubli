[SmartApp](../classes/_smart_app_d_.smartapp.md)

### Type aliases

* [HandlerResponse](_smart_app_d_.md#handlerresponse)

## Type aliases

###  HandlerResponse

Ƭ **HandlerResponse**: *void | Promise‹void›*

Return type of lifecycle event handlers
