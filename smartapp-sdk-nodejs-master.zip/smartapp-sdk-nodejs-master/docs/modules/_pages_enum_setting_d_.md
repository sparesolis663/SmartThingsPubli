[SmartApp](../classes/_smart_app_d_.smartapp.md)

### Type aliases

* [OptionList](_pages_enum_setting_d_.md#optionlist)

## Type aliases

###  OptionList

Ƭ **OptionList**: *string[] | [OptionItem](../interfaces/_pages_enum_setting_d_.optionitem.md)[] | object*
