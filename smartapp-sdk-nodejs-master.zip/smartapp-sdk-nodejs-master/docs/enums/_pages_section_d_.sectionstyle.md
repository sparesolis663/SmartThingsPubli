[Reference](../index.md) › [SmartApp](../classes/_smart_app_d_.smartapp.md) ›  [SectionStyle](_pages_section_d_.sectionstyle.md)
# SectionStyle
## Enumeration members
###  NORMAL

• **NORMAL**: = "NORMAL"

___

###  SPLASH

• **SPLASH**: = "SPLASH"

