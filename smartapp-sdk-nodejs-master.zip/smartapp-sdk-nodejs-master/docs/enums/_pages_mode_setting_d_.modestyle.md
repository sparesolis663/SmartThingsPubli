[SmartApp](../classes/_smart_app_d_.smartapp.md) › [Page](../classes/_pages_page_d_.page.md) › [Section](../classes/_pages_section_d_.section.md) ›  [ModeSetting](_pages_mode_setting_d_.modesetting.md) ›  [ModeStyle](_pages_mode_setting_d_.modestyle.md)
# ModeStyle
## Enumeration members
###  COMPLETE

• **COMPLETE**: = "COMPLETE"

___

###  DEFAULT

• **DEFAULT**: = "DEFAULT"

___

###  ERROR

• **ERROR**: = "ERROR"

