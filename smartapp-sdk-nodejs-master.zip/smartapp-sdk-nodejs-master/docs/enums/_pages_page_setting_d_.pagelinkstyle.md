[SmartApp](../classes/_smart_app_d_.smartapp.md) › [Page](../classes/_pages_page_d_.page.md) › [Section](../classes/_pages_section_d_.section.md) ›  [PageSetting](_pages_page_setting_d_.pagesetting.md) ›  [PageLinkStyle](_pages_page_setting_d_.pagelinkstyle.md)
# PageLinkStyle
## Enumeration members
###  BUTTON

• **BUTTON**: = "BUTTON"

___

###  COMPLETE

• **COMPLETE**: = "COMPLETE"

___

###  DEFAULT

• **DEFAULT**: = "DEFAULT"

___

###  ERROR

• **ERROR**: = "ERROR"

