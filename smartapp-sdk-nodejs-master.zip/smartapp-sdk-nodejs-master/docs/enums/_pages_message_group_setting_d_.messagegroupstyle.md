[SmartApp](../classes/_smart_app_d_.smartapp.md) › [Page](../classes/_pages_page_d_.page.md) › [Section](../classes/_pages_section_d_.section.md) ›  [MessageGroupSetting](_pages_message_group_setting_d_.messagegroupsetting.md) ›  [MessageGroupStyle](_pages_message_group_setting_d_.messagegroupstyle.md)
# MessageGroupStyle
## Enumeration members
###  COMPLETE

• **COMPLETE**: = "COMPLETE"

___

###  DEFAULT

• **DEFAULT**: = "DEFAULT"

___

###  DROPDOWN

• **DROPDOWN**: = "DROPDOWN"

___

###  ERROR

• **ERROR**: = "ERROR"

