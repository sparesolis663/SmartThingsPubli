[SmartApp](../classes/_smart_app_d_.smartapp.md) › [Page](../classes/_pages_page_d_.page.md) › [Section](../classes/_pages_section_d_.section.md) ›  [NumberSetting](_pages_number_setting_d_.numbersetting.md) ›  [NumberStyle](_pages_number_setting_d_.numberstyle.md)
# NumberStyle
## Enumeration members
###  SLIDER

• **SLIDER**: = "SLIDER"

