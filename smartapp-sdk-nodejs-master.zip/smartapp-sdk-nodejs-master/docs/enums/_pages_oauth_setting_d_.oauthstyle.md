[SmartApp](../classes/_smart_app_d_.smartapp.md) › [Page](../classes/_pages_page_d_.page.md) › [Section](../classes/_pages_section_d_.section.md) ›  [OAuthSetting](_pages_oauth_setting_d_.oauthsetting.md) ›  [OAuthStyle](_pages_oauth_setting_d_.oauthstyle.md)
# OAuthStyle
## Enumeration members
###  COMPLETE

• **COMPLETE**: = "COMPLETE"

___

###  DEFAULT

• **DEFAULT**: = "DEFAULT"

___

###  ERROR

• **ERROR**: = "ERROR"

