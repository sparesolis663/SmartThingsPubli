[Reference](../index.md) › [SmartApp](../classes/_smart_app_d_.smartapp.md) ›  [PageStyle](_pages_page_d_.pagestyle.md)
# PageStyle
## Enumeration members
###  NORMAL

• **NORMAL**: = "NORMAL"

___

###  SPLASH

• **SPLASH**: = "SPLASH"

