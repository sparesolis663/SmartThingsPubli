[SmartApp](../classes/_smart_app_d_.smartapp.md) › [Page](../classes/_pages_page_d_.page.md) › [Section](../classes/_pages_section_d_.section.md) ›  [SecuritySetting](_pages_security_setting_d_.securitysetting.md) ›  [SecurityStyle](_pages_security_setting_d_.securitystyle.md)
# SecurityStyle
## Enumeration members
###  COMPLETE

• **COMPLETE**: = "COMPLETE"

___

###  DEFAULT

• **DEFAULT**: = "DEFAULT"

___

###  DROPDOWN

• **DROPDOWN**: = "BUTTON"

___

###  ERROR

• **ERROR**: = "ERROR"

