[SmartApp](../classes/_smart_app_d_.smartapp.md) ›  [ContextStore](_smart_app_d_.contextstore.md)
# ContextStore
## Methods

* [get](_smart_app_d_.contextstore.md#get)
* [put](_smart_app_d_.contextstore.md#put)


###  get

▸ **get**(`installedAppId`: string): *Promise‹[ContextRecord](_smart_app_d_.contextrecord.md)›*

**Parameters:**

Name | Type |
------ | ------ |
`installedAppId` | string |

**Returns:** *Promise‹[ContextRecord](_smart_app_d_.contextrecord.md)›*

___

###  put

▸ **put**(`contextRecord`: [ContextRecord](_smart_app_d_.contextrecord.md)): *Promise‹[ContextRecord](_smart_app_d_.contextrecord.md)›*

**Parameters:**

Name | Type |
------ | ------ |
`contextRecord` | [ContextRecord](_smart_app_d_.contextrecord.md) |

**Returns:** *Promise‹[ContextRecord](_smart_app_d_.contextrecord.md)›*

