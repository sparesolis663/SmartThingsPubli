[SmartApp](../classes/_smart_app_d_.smartapp.md) ›  [WebHookRequest](_smart_app_d_.webhookrequest.md)
# WebHookRequest
## Properties

* [body](_smart_app_d_.webhookrequest.md#body)
* [headers](_smart_app_d_.webhookrequest.md#headers)


###  body

• **body**: *any*

___

###  headers

• **headers**: *IncomingHttpHeaders*

