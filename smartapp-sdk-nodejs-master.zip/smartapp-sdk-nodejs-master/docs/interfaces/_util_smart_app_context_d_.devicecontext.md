[SmartApp](../classes/_smart_app_d_.smartapp.md) ›  [DeviceContext](_util_smart_app_context_d_.devicecontext.md)
# DeviceContext
## Properties

* [componentId](_util_smart_app_context_d_.devicecontext.md#componentid)
* [deviceId](_util_smart_app_context_d_.devicecontext.md#deviceid)
* [label](_util_smart_app_context_d_.devicecontext.md#label)
* [name](_util_smart_app_context_d_.devicecontext.md#name)


###  componentId

• **componentId**: *string*

___

###  deviceId

• **deviceId**: *string*

___

###  label

• **label**: *string*

___

###  name

• **name**: *string*

