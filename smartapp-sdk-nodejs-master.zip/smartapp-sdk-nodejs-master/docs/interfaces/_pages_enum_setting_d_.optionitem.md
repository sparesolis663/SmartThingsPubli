[SmartApp](../classes/_smart_app_d_.smartapp.md) ›  [OptionItem](_pages_enum_setting_d_.optionitem.md)
# OptionItem
## Properties

* [id](_pages_enum_setting_d_.optionitem.md#id)
* [name](_pages_enum_setting_d_.optionitem.md#name)


###  id

• **id**: *string*

___

###  name

• **name**: *string*

