[SmartApp](../classes/_smart_app_d_.smartapp.md) ›  [SoundOptionItem](_pages_sound_setting_d_.soundoptionitem.md)
# SoundOptionItem
## Properties

* [id](_pages_sound_setting_d_.soundoptionitem.md#id)
* [name](_pages_sound_setting_d_.soundoptionitem.md#name)
* [sound](_pages_sound_setting_d_.soundoptionitem.md#sound)


###  id

• **id**: *string*

___

###  name

• **name**: *string*

___

###  sound

• **sound**: *string*

