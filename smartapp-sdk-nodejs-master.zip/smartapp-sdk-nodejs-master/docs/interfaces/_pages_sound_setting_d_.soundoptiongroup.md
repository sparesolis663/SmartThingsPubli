[SmartApp](../classes/_smart_app_d_.smartapp.md) ›  [SoundOptionGroup](_pages_sound_setting_d_.soundoptiongroup.md)
# SoundOptionGroup
## Properties

* [name](_pages_sound_setting_d_.soundoptiongroup.md#name)
* [options](_pages_sound_setting_d_.soundoptiongroup.md#options)


###  name

• **name**: *string*

___

###  options

• **options**: *[SoundOptionItem](_pages_sound_setting_d_.soundoptionitem.md)[]*

