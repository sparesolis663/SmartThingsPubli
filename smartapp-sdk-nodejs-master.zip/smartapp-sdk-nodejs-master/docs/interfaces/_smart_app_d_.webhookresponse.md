[SmartApp](../classes/_smart_app_d_.smartapp.md) ›  [WebHookResponse](_smart_app_d_.webhookresponse.md)
# WebHookResponse
## Methods

* [json](_smart_app_d_.webhookresponse.md#json)
* [send](_smart_app_d_.webhookresponse.md#send)
* [status](_smart_app_d_.webhookresponse.md#status)


###  json

▸ **json**(`data`: any): *[WebHookResponse](_smart_app_d_.webhookresponse.md)*

**Parameters:**

Name | Type |
------ | ------ |
`data` | any |

**Returns:** *[WebHookResponse](_smart_app_d_.webhookresponse.md)*

___

###  send

▸ **send**(`data`: any): *[WebHookResponse](_smart_app_d_.webhookresponse.md)*

**Parameters:**

Name | Type |
------ | ------ |
`data` | any |

**Returns:** *[WebHookResponse](_smart_app_d_.webhookresponse.md)*

___

###  status

▸ **status**(`code`: number): *[WebHookResponse](_smart_app_d_.webhookresponse.md)*

**Parameters:**

Name | Type |
------ | ------ |
`code` | number |

**Returns:** *[WebHookResponse](_smart_app_d_.webhookresponse.md)*

