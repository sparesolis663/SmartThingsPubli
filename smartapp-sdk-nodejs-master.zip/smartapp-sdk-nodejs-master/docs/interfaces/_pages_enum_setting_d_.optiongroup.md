[SmartApp](../classes/_smart_app_d_.smartapp.md) ›  [OptionGroup](_pages_enum_setting_d_.optiongroup.md)
# OptionGroup
## Properties

* [name](_pages_enum_setting_d_.optiongroup.md#name)
* [options](_pages_enum_setting_d_.optiongroup.md#options)


###  name

• **name**: *string*

___

###  options

• **options**: *[OptionList](../modules/_pages_enum_setting_d_.md#optionlist)*

