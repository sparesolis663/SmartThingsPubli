[SmartApp](../classes/_smart_app_d_.smartapp.md) ›  [DeviceStateContext](_util_smart_app_context_d_.devicestatecontext.md)
# DeviceStateContext
## Properties

* [componentId](_util_smart_app_context_d_.devicestatecontext.md#componentid)
* [deviceId](_util_smart_app_context_d_.devicestatecontext.md#deviceid)
* [label](_util_smart_app_context_d_.devicestatecontext.md#label)
* [name](_util_smart_app_context_d_.devicestatecontext.md#name)
* [state](_util_smart_app_context_d_.devicestatecontext.md#state)


###  componentId

• **componentId**: *string*

*Inherited from [DeviceContext](_util_smart_app_context_d_.devicecontext.md).[componentId](_util_smart_app_context_d_.devicecontext.md#componentid)*

___

###  deviceId

• **deviceId**: *string*

*Inherited from [DeviceContext](_util_smart_app_context_d_.devicecontext.md).[deviceId](_util_smart_app_context_d_.devicecontext.md#deviceid)*

___

###  label

• **label**: *string*

*Inherited from [DeviceContext](_util_smart_app_context_d_.devicecontext.md).[label](_util_smart_app_context_d_.devicecontext.md#label)*

___

###  name

• **name**: *string*

*Inherited from [DeviceContext](_util_smart_app_context_d_.devicecontext.md).[name](_util_smart_app_context_d_.devicecontext.md#name)*

___

###  state

• **state**: *object*

#### Type declaration:

* \[ **componentId**: *string*\]: ComponentStatus

